document.addEventListener('DOMContentLoaded', () => {
    // Navigation Handler
    const navButtons = document.querySelectorAll('.nav-btn');
    const sections = document.querySelectorAll('main section');

    navButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Remove active class from all buttons and sections
            navButtons.forEach(btn => btn.classList.remove('active'));
            sections.forEach(section => section.classList.remove('active'));

            // Add active class to clicked button and corresponding section
            button.classList.add('active');
            const sectionId = button.dataset.section;
            document.getElementById(sectionId).classList.add('active');
        });
    });

    // Messaging Functionality
    class MessageManager {
        constructor() {
            this.messageContainer = document.getElementById('message-container');
            this.messageInput = document.getElementById('message-input');
            this.sendMessageBtn = document.getElementById('send-message');

            this.contacts = [
                {
                    id: 1,
                    name: 'John Doe',
                    messages: [
                        { text: 'Hey, how are you?', type: 'received' },
                        { text: 'What projects are you working on?', type: 'received' }
                    ]
                },
                {
                    id: 2,
                    name: 'Jane Smith',
                    messages: [
                        { text: 'Hi there!', type: 'received' },
                        { text: 'Interesting startup idea.', type: 'received' }
                    ]
                }
            ];

            this.currentContactId = 1;
            this.setupEventListeners();
            this.loadInitialMessages();
        }

        setupEventListeners() {
            this.sendMessageBtn.addEventListener('click', () => this.sendMessage());
            this.messageInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') this.sendMessage();
            });
        }

        createMessageElement(message, type) {
            const messageElement = document.createElement('div');
            messageElement.classList.add('message', type);

            const contentElement = document.createElement('div');
            contentElement.classList.add('message-content');
            contentElement.textContent = message;

            const timeElement = document.createElement('div');
            timeElement.classList.add('message-time');
            timeElement.textContent = this.formatTime(new Date());

            messageElement.appendChild(contentElement);
            messageElement.appendChild(timeElement);
            return messageElement;
        }

        formatTime(date) {
            return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        }

        sendMessage() {
            const message = this.messageInput.value.trim();
            if (message) {
                // Send user message
                const sentMessage = this.createMessageElement(message, 'sent');
                this.messageContainer.appendChild(sentMessage);

                // Store message in contact's message history
                const currentContact = this.contacts.find(c => c.id === this.currentContactId);
                if (currentContact) {
                    currentContact.messages.push({ text: message, type: 'sent' });
                }

                // Simulate AI/Bot response
                this.simulateResponse();

                // Clear input
                this.messageInput.value = '';

                // Scroll to bottom
                this.messageContainer.scrollTop = this.messageContainer.scrollHeight;
            }
        }

        simulateResponse() {
            const responses = [
                "That sounds interesting!",
                "Could you tell me more about your idea?",
                "Sounds like an exciting project!",
                "Have you considered this approach?",
                "Interesting perspective!"
            ];

            setTimeout(() => {
                const response = responses[Math.floor(Math.random() * responses.length)];
                const receivedMessage = this.createMessageElement(response, 'received');
                this.messageContainer.appendChild(receivedMessage);

                // Store response in contact's message history
                const currentContact = this.contacts.find(c => c.id === this.currentContactId);
                if (currentContact) {
                    currentContact.messages.push({ text: response, type: 'received' });
                }

                // Scroll to bottom
                this.messageContainer.scrollTop = this.messageContainer.scrollHeight;
            }, 1000);
        }

        loadInitialMessages() {
            // Load messages for current contact
            const currentContact = this.contacts.find(c => c.id === this.currentContactId);
            if (currentContact) {
                this.messageContainer.innerHTML = '';
                currentContact.messages.forEach(msg => {
                    const messageElement = this.createMessageElement(msg.text, msg.type);
                    this.messageContainer.appendChild(messageElement);
                });
            }
        }
    }

    // Mentor Matchmaking Functionality
    class MentorMatchmaker {
        constructor() {
            this.industryFilter = document.getElementById('industry-filter');
            this.expertiseFilter = document.getElementById('expertise-filter');
            this.findMatchBtn = document.getElementById('find-match');
            this.matchResults = document.getElementById('match-results');

            this.mentors = [
                {
                    name: 'Sarah Johnson',
                    industry: 'tech',
                    expertise: 'funding',
                    bio: 'Serial entrepreneur with 10+ years of startup experience',
                    rating: 4.8
                },
                {
                    name: 'Michael Chen',
                    industry: 'tech',
                    expertise: 'strategy',
                    bio: 'Venture capitalist specializing in early-stage startups',
                    rating: 4.9
                },
                {
                    name: 'Emily Rodriguez',
                    industry: 'finance',
                    expertise: 'funding',
                    bio: 'Investment banker turned startup mentor',
                    rating: 4.7
                }
            ];

            this.setupEventListeners();
        }

        setupEventListeners() {
            this.findMatchBtn.addEventListener('click', () => this.findMentorMatch());
        }

        findMentorMatch() {
            const industry = this.industryFilter.value;
            const expertise = this.expertiseFilter.value;

            // Clear previous results
            this.matchResults.innerHTML = '';

            // Filter matches
            const filteredMatches = this.mentors.filter(match =>
                (!industry || match.industry === industry) &&
                (!expertise || match.expertise === expertise)
            );

            // Render matches
            filteredMatches.forEach(match => {
                const matchCard = document.createElement('div');
                matchCard.classList.add('match-card');
                matchCard.innerHTML = `
                    <img src="/api/placeholder/100/100" alt="${match.name}">
                    <h3>${match.name}</h3>
                    <div class="match-details">
                        <p><strong>Industry:</strong> ${match.industry}</p>
                        <p><strong>Expertise:</strong> ${match.expertise}</p>
                        <p class="rating">
                            <i class="fas fa-star"></i> ${match.rating}/5
                        </p>
                        <p class="bio">${match.bio}</p>
                    </div>
                    <div class="match-actions">
                        <button class="btn-connect">Connect</button>
                        <button class="btn-message">Message</button>
                    </div>
                `;
                this.matchResults.appendChild(matchCard);

                // Add event listeners to connect/message buttons
                const connectBtn = matchCard.querySelector('.btn-connect');
                const messageBtn = matchCard.querySelector('.btn-message');

                connectBtn.addEventListener('click', () => this.requestConnection(match));
                messageBtn.addEventListener('click', () => this.initiateChat(match));
            });
        }

        requestConnection(mentor) {
            // Simulate connection request
            alert(`Connection request sent to ${mentor.name}!`);
        }

        initiateChat(mentor) {
            // In a real app, this would open a chat with the mentor
            alert(`Starting a chat with ${mentor.name}`);
        }
    }

    // Dashboard Interaction
    class DashboardManager {
        constructor() {
            this.setupNotificationHandlers();
        }

        setupNotificationHandlers() {
            const notificationCards = document.querySelectorAll('.dashboard-card');

            notificationCards.forEach(card => {
                card.addEventListener('click', () => {
                    const badgeElement = card.querySelector('.badge');
                    if (badgeElement) {
                        const notificationType = card.querySelector('h3').textContent;
                        this.handleNotificationClick(notificationType);
                    }
                });
            });
        }

        handleNotificationClick(type) {
            switch (type) {
                case 'Unread Messages':
                    // Switch to messaging section
                    document.querySelector('.nav-btn[data-section="direct-messaging"]').click();
                    break;
                case 'New Connections':
                    // Open connections modal or section
                    alert('Showing new connection requests');
                    break;
                case 'Notifications':
                    // Show full notifications
                    alert('Showing all notifications');
                    break;
                case 'Profile Views':
                    // Show profile analytics
                    alert('Showing profile view analytics');
                    break;
            }
        }
    }

    // Initialize Managers
    new MessageManager();
    new MentorMatchmaker();
    new DashboardManager();
});

document.addEventListener('DOMContentLoaded', () => {
    // Smooth Section Transitions
    const navButtons = document.querySelectorAll('.nav-btn');
    const sections = document.querySelectorAll('main section');

    function smoothSectionTransition(targetSection) {
        // Hide all sections
        sections.forEach(section => {
            section.classList.remove('active');
            section.style.opacity = '0';
            section.style.transform = 'translateY(20px)';
        });

        // Remove active from all nav buttons
        navButtons.forEach(btn => btn.classList.remove('active'));

        // Activate target section
        const sectionToShow = document.getElementById(targetSection);
        if (sectionToShow) {
            sectionToShow.classList.add('active');

            // Animate section entrance
            setTimeout(() => {
                sectionToShow.style.opacity = '1';
                sectionToShow.style.transform = 'translateY(0)';
            }, 50);
        }

        // Activate corresponding nav button
        const activeNavButton = document.querySelector(`.nav-btn[data-section="${targetSection}"]`);
        if (activeNavButton) {
            activeNavButton.classList.add('active');
        }
    }

    navButtons.forEach(button => {
        button.addEventListener('click', () => {
            const sectionId = button.dataset.section;
            smoothSectionTransition(sectionId);
        });
    });

    // Initial section setup
    smoothSectionTransition('dashboard');

    // Existing classes from previous implementation (MessageManager, etc.)
    // ... [Keep the existing classes from the previous JavaScript]

    // Enhanced Dashboard Interaction
    class EnhancedDashboardManager {
        constructor() {
            this.setupNotificationHandlers();
            this.initializeAnimations();
        }

        initializeAnimations() {
            const dashboardCards = document.querySelectorAll('.dashboard-card');
            dashboardCards.forEach(card => {
                card.addEventListener('mouseenter', () => {
                    card.style.transform = 'scale(1.05)';
                });
                card.addEventListener('mouseleave', () => {
                    card.style.transform = 'scale(1)';
                });
            });
        }

        setupNotificationHandlers() {
            const notificationCards = document.querySelectorAll('.dashboard-card');

            notificationCards.forEach(card => {
                card.addEventListener('click', () => {
                    const badgeElement = card.querySelector('.badge');
                    if (badgeElement) {
                        const notificationType = card.querySelector('h3').textContent;
                        this.handleNotificationClick(notificationType);
                    }
                });
            });
        }

        handleNotificationClick(type) {
            switch (type) {
                case 'Unread Messages':
                    smoothSectionTransition('direct-messaging');
                    break;
                case 'New Connections':
                    this.showConnectionModal();
                    break;
                case 'Notifications':
                    this.showAllNotifications();
                    break;
                case 'Profile Views':
                    smoothSectionTransition('profile');
                    break;
            }
        }

        showConnectionModal() {
            const modal = document.createElement('div');
            modal.classList.add('modal');
            modal.innerHTML = `
                <div class="modal-content">
                    <span class="close-modal">&times;</span>
                    <h2>New Connection Requests</h2>
                    <div class="connection-requests">
                        <div class="request">
                            <img src="/api/placeholder/50/50">
                            <div class="request-info">
                                <h3>Alex Thompson</h3>
                                <p>Wants to connect</p>
                            </div>
                            <div class="request-actions">
                                <button class="accept">Accept</button>
                                <button class="decline">Decline</button>
                            </div>
                        </div>
                        <!-- More connection requests -->
                    </div>
                </div>
            `;

            document.body.appendChild(modal);
            modal.style.display = 'flex';

            modal.querySelector('.close-modal').addEventListener('click', () => {
                document.body.removeChild(modal);
            });
        }

        showAllNotifications() {
            const modal = document.createElement('div');
            modal.classList.add('modal');
            modal.innerHTML = `
                <div class="modal-content">
                    <span class="close-modal">&times;</span>
                    <h2>All Notifications</h2>
                    <div class="notification-list">
                        <div class="notification">
                            <i class="fas fa-bell"></i>
                            <div class="notification-details">
                                <p>New message from John Doe</p>
                                <small>2 minutes ago</small>
                            </div>
                        </div>
                        <!-- More notifications -->
                    </div>
                </div>
            `;

            document.body.appendChild(modal);
            modal.style.display = 'flex';

            modal.querySelector('.close-modal').addEventListener('click', () => {
                document.body.removeChild(modal);
            });
        }
    }

    // Initialize Enhanced Managers
    new MessageManager();
    new MentorMatchmaker();
    new EnhancedDashboardManager();
});

document.addEventListener('DOMContentLoaded', function () {
    // Check if user is logged in
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    if (!isLoggedIn) {
        window.location.href = '../Login/login.html';
        return;
    }

    // Get current user
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (!currentUser) {
        localStorage.removeItem('isLoggedIn');
        window.location.href = '../Login/login.html';
        return;
    }

    // Set user greeting
    const userGreeting = document.getElementById('userGreeting');
    if (userGreeting) {
        userGreeting.textContent = `Welcome, ${currentUser.fullName}!`;
    }

    // Display profile info
    displayProfileInfo(currentUser.id);

    // Logout button handler
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
});

// Display user profile information
function displayProfileInfo(userId) {
    const profileInfo = document.getElementById('profileInfo');
    if (!profileInfo) return;

    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const user = users.find(user => user.id === userId);

    if (!user) {
        profileInfo.innerHTML = '<p>Error loading profile information</p>';
        return;
    }

    // Create profile HTML
    let html = `
        <div class="profile-detail">
            <strong>Name:</strong> ${user.fullName}
        </div>
        <div class="profile-detail">
            <strong>Email:</strong> ${user.email}
        </div>
        <div class="profile-detail">
            <strong>Role:</strong> ${user.role.charAt(0).toUpperCase() + user.role.slice(1)}
        </div>
    `;

    if (user.education) {
        html += `
            <div class="profile-detail">
                <strong>Education:</strong>
                <p>${user.education}</p>
            </div>
        `;
    }

    if (user.experience) {
        html += `
            <div class="profile-detail">
                <strong>Experience:</strong>
                <p>${user.experience}</p>
            </div>
        `;
    }

    if (user.interests) {
        html += `
            <div class="profile-detail">
                <strong>Interests:</strong>
                <p>${user.interests}</p>
            </div>
        `;
    }

    profileInfo.innerHTML = html;
}

// Handle logout
function handleLogout() {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('currentUser');
    window.location.href = '../Login/login.html';
}

// Mobile Navigation
const hamburger = document.querySelector('.hamburger');
const navLinks = document.querySelector('.nav-links');

if (hamburger) {
    hamburger.addEventListener('click', () => {
        navLinks.classList.toggle('show');
    });
}

// Counter Animation
const counters = document.querySelectorAll('.counter');
const speed = 200;

function animateCounters() {
    counters.forEach(counter => {
        const target = +counter.getAttribute('data-target');
        const count = +counter.innerText;

        const increment = target / speed;

        if (count < target) {
            counter.innerText = Math.ceil(count + increment);
            setTimeout(animateCounters, 1);
        } else {
            counter.innerText = target.toLocaleString();
        }
    });
}

// Check if element is in viewport
function isInViewport(element) {
    const rect = element.getBoundingClientRect();
    return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
}

// Start animation when stats section is in viewport
const statsSection = document.querySelector('.stats');
let hasAnimated = false;

window.addEventListener('scroll', () => {
    if (isInViewport(statsSection) && !hasAnimated) {
        animateCounters();
        hasAnimated = true;
    }
});

// Testimonial Slider
const slides = document.querySelectorAll('.testimonial-slide');
const dots = document.querySelectorAll('.dot');
const prevBtn = document.querySelector('.prev-btn');
const nextBtn = document.querySelector('.next-btn');
let currentSlide = 0;

function showSlide(n) {
    slides.forEach(slide => slide.classList.remove('active'));
    dots.forEach(dot => dot.classList.remove('active'));

    currentSlide = (n + slides.length) % slides.length;

    slides[currentSlide].classList.add('active');
    dots[currentSlide].classList.add('active');
}

function nextSlide() {
    showSlide(currentSlide + 1);
}

function prevSlide() {
    showSlide(currentSlide - 1);
}

if (prevBtn && nextBtn) {
    prevBtn.addEventListener('click', prevSlide);
    nextBtn.addEventListener('click', nextSlide);
}

dots.forEach((dot, index) => {
    dot.addEventListener('click', () => {
        showSlide(index);
    });
});

// Auto-advance slides
let slideInterval = setInterval(nextSlide, 6000);

// Pause auto-advance on hover
const testimonialSlider = document.querySelector('.testimonial-slider');
if (testimonialSlider) {
    testimonialSlider.addEventListener('mouseenter', () => {
        clearInterval(slideInterval);
    });

    testimonialSlider.addEventListener('mouseleave', () => {
        slideInterval = setInterval(nextSlide, 6000);
    });
}

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();

        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            window.scrollTo({
                top: target.offsetTop,
                behavior: 'smooth'
            });
        }
    });
});

// Mobile responsive navbar
window.addEventListener('resize', () => {
    if (window.innerWidth > 1024) {
        navLinks.classList.remove('show');
    }
});